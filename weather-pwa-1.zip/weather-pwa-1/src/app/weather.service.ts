// weather.service.ts

import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class WeatherService {

  private apiUrl = 'https://weather-api99.p.rapidapi.com/weather';
  private rapidApiKey = 'ea6b8aeeabmsh699e1c6df5a1814p1a7d8bjsna2a1f29ac9a9';

  constructor(private http: HttpClient) { }

  getWeather(city: string): Observable<any> {
    const headers = new HttpHeaders({
      'x-rapidapi-key': 'ea6b8aeeabmsh699e1c6df5a1814p1a7d8bjsna2a1f29ac9a9',
      'x-rapidapi-host': 'weather-api99.p.rapidapi.com'
    });
    
    
  
    return this.http.get<any>(`https://weather-api99.p.rapidapi.com/weather?city=${city}`, { headers });
  }
}
