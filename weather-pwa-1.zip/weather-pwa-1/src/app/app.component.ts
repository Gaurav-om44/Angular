// app.component.ts

import { Component, OnInit } from '@angular/core';
import { WeatherService } from './weather.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  city: string = 'London';
  weatherData: any = null;
  errorMessage: string = '';

  constructor(private weatherService: WeatherService) { }

  ngOnInit() {
    this.fetchWeatherData(this.city);
  }

  fetchWeatherData(city: string) {
    this.weatherService.getWeather(city).subscribe(
      (data) => {
        this.weatherData = data;
        this.errorMessage = '';
        console.log(`Weather data for ${city}:`, data);
      },
      (error) => {
        this.weatherData = null;
        this.errorMessage = `Error fetching weather data for ${city}: ${error.message}`;
        console.error(this.errorMessage);
      }
    );
  }
}
